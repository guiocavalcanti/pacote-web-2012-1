// O .ready espera a DOM, JS e imagens carregarem
$(document).ready(function(){
    var todo = {
      url : "http://todoing.heroku.com/todos.json",
      urlRemocao : function(id){
        return "http://todoing.heroku.com/todos/" + id  + ".json";
      }
    };

    var $item = $("<span class=\"description\"></span><input class=\"remover\" value=\"Remover\">");

});
